﻿namespace Unidux.Example.MultipleState
{
    public enum Friend
    {
        ServalCat,
        AraiBear,
        Tsuchinoko,
    }
}
