﻿using System.Collections;

public class DebugInfo
{
    public string PreviousId;
    public string ActionId;
    public object[] Variables;

    public int Result { get; set; }
}
