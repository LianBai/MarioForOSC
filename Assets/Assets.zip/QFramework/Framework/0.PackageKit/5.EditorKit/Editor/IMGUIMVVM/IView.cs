namespace QF
{
    public class IView<T> where T : IView<T>
    {
        
    }
}