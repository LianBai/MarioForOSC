namespace QF
{
    public class IGUIView
    {
        
    }
}