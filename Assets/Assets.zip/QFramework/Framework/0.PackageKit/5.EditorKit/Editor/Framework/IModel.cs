namespace EGO.Framework
{
    public interface IModel
    {
        
    }
}