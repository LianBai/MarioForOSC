namespace QF.Editor
{
    public class StyleConfig
    {
        
    }
}